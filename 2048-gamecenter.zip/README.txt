Sarah Ruckhaus
COMP 20
Assignment 4
10 April 2014

--Everything works (I hope). It doesn't look pretty, but it works.
--I "collaborated" with the people at Andrew's office hours on Monday, but that was mostly all of us being confused together.
--Total time: at least 13 hours

The score and grid are stored in game_manager.js as GameManager.score and GameManager.grid, respectively. I used GameManager.grid.serialize() when I posted it to the server.

2048 files changed:
--Added <script> for jQuery to index.html <head>
--put the follwing in game_manager.js after line 89 (if(this.over)):
	$.post("http://http://peaceful-brushlands-5376.herokuapp.com/submit.json",{'score':this.score, 'grid':this.grid.serialize()});

Username hardcoded as "jon snow" in my app.js file (line 29).
