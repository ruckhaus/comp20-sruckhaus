// Initialize express
var express = require('express');
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title','2048 gamecenter');

// Initialize mongodb
var mongo = require('mongodb');
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/2048-gamecenter';
var db = mongo.Db.connect(mongoUri, function (error, dbConnection) {
	db = dbConnection;
});

app.all('*', function(request, response, next) {
	// Enable CORS, via http://enable-cors.org/server_expressjs.html
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	next();
 });

app.post('/submit.json', function (request, response) {
	// submits username, final score, and grid for terminated game
	var gameDate = new Date();
	var timestamp = gameDate.toUTCString();

	// Get data from 2048 (score and grid)
	var username = 'jon snow';
	var score = parseInt(request.body.score); // works for curl, not 2048
	var grid = JSON.stringify(request.body.grid);	  // works for curl, not 2048

	// add game data to mongo collection
	if((username && score) && grid) {
		mongo.Db.connect(mongoUri, function (err, db) {
			db.collection("scores", function (er, collection) {
				collection.insert({"username":username, "score":score, "grid":grid,"created_at":timestamp}, function (err, r) {});
			response.send('Scores successfully added.\n');
			});
		});
	}
	else {
		// request doesn't have all necessary components
		response.send('No data for you.\n');
	}
});

app.get('/scores.json', function (request, response) {
	// returns JSON of specified player's scores sorted in descending order
	var name=request.query.username;
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection("scores", function (er, collection) {
			collection.find({'username': name}, {'sort': [['score',-1]]}).toArray(function (err, results) {
				response.set('Content-Type', 'text/json');
				response.send(results);
			});
		});
	});
});

app.get('/', function (request, response) {
	// display list of all game scores for all players in descending order
	var table = '<table><thead><td>Username</td><td>Score</td><td>Date</td></thead>';
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection("scores", function (er, collection) {
			collection.find({}, {'sort': [['score',-1]]}).toArray(function (err, results) {
				for (var i=0; i<results.length; i++) {
					// loop through results and add to HTML table
					table+= '<tr><td>' + results[i].username + '</td><td>' + results[i].score + '</td><td>'+ results[i].created_at + '</td></tr>';
				}
				table+='</table>';
				response.send(table);
			});
		});
	});
});

var port = Number(process.env.PORT || 3000);
app.listen(port, function () {
	console.log("listening on port " + port);
});
